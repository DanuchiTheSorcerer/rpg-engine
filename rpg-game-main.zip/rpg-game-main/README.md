# rpg-game
This is a game made because I was bored in school. I would have made it in a better language but chromebooks suck.
